﻿namespace ATSCADA.iGraphicTools.Image
{
    partial class frmImage3PosSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbPositionImage = new System.Windows.Forms.GroupBox();
            this.btnPosition3 = new System.Windows.Forms.Button();
            this.txtPosition3 = new System.Windows.Forms.TextBox();
            this.lblPosition3 = new System.Windows.Forms.Label();
            this.btnPosition2 = new System.Windows.Forms.Button();
            this.txtPosition2 = new System.Windows.Forms.TextBox();
            this.lblPosition2 = new System.Windows.Forms.Label();
            this.btnPosition1 = new System.Windows.Forms.Button();
            this.txtPosition1 = new System.Windows.Forms.TextBox();
            this.lblPositon1 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.grbPositionImage.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbPositionImage
            // 
            this.grbPositionImage.Controls.Add(this.btnPosition3);
            this.grbPositionImage.Controls.Add(this.txtPosition3);
            this.grbPositionImage.Controls.Add(this.lblPosition3);
            this.grbPositionImage.Controls.Add(this.btnPosition2);
            this.grbPositionImage.Controls.Add(this.txtPosition2);
            this.grbPositionImage.Controls.Add(this.lblPosition2);
            this.grbPositionImage.Controls.Add(this.btnPosition1);
            this.grbPositionImage.Controls.Add(this.txtPosition1);
            this.grbPositionImage.Controls.Add(this.lblPositon1);
            this.grbPositionImage.Location = new System.Drawing.Point(15, 9);
            this.grbPositionImage.Name = "grbPositionImage";
            this.grbPositionImage.Size = new System.Drawing.Size(352, 126);
            this.grbPositionImage.TabIndex = 6;
            this.grbPositionImage.TabStop = false;
            this.grbPositionImage.Text = "Position Image";
            // 
            // btnPosition3
            // 
            this.btnPosition3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPosition3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosition3.Location = new System.Drawing.Point(304, 89);
            this.btnPosition3.Name = "btnPosition3";
            this.btnPosition3.Size = new System.Drawing.Size(35, 23);
            this.btnPosition3.TabIndex = 5;
            this.btnPosition3.Text = "...";
            this.btnPosition3.UseVisualStyleBackColor = true;
            // 
            // txtPosition3
            // 
            this.txtPosition3.Enabled = false;
            this.txtPosition3.Location = new System.Drawing.Point(76, 89);
            this.txtPosition3.Multiline = true;
            this.txtPosition3.Name = "txtPosition3";
            this.txtPosition3.Size = new System.Drawing.Size(222, 23);
            this.txtPosition3.TabIndex = 4;
            this.txtPosition3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPosition3
            // 
            this.lblPosition3.AutoSize = true;
            this.lblPosition3.Location = new System.Drawing.Point(7, 93);
            this.lblPosition3.Name = "lblPosition3";
            this.lblPosition3.Size = new System.Drawing.Size(61, 15);
            this.lblPosition3.TabIndex = 7;
            this.lblPosition3.Text = "Position 3";
            // 
            // btnPosition2
            // 
            this.btnPosition2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPosition2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosition2.Location = new System.Drawing.Point(304, 58);
            this.btnPosition2.Name = "btnPosition2";
            this.btnPosition2.Size = new System.Drawing.Size(35, 23);
            this.btnPosition2.TabIndex = 3;
            this.btnPosition2.Text = "...";
            this.btnPosition2.UseVisualStyleBackColor = true;
            // 
            // txtPosition2
            // 
            this.txtPosition2.Enabled = false;
            this.txtPosition2.Location = new System.Drawing.Point(76, 58);
            this.txtPosition2.Multiline = true;
            this.txtPosition2.Name = "txtPosition2";
            this.txtPosition2.Size = new System.Drawing.Size(222, 23);
            this.txtPosition2.TabIndex = 2;
            this.txtPosition2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPosition2
            // 
            this.lblPosition2.AutoSize = true;
            this.lblPosition2.Location = new System.Drawing.Point(7, 62);
            this.lblPosition2.Name = "lblPosition2";
            this.lblPosition2.Size = new System.Drawing.Size(61, 15);
            this.lblPosition2.TabIndex = 4;
            this.lblPosition2.Text = "Position 2";
            // 
            // btnPosition1
            // 
            this.btnPosition1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPosition1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosition1.Location = new System.Drawing.Point(304, 27);
            this.btnPosition1.Name = "btnPosition1";
            this.btnPosition1.Size = new System.Drawing.Size(35, 23);
            this.btnPosition1.TabIndex = 1;
            this.btnPosition1.Text = "...";
            this.btnPosition1.UseVisualStyleBackColor = true;
            // 
            // txtPosition1
            // 
            this.txtPosition1.Enabled = false;
            this.txtPosition1.Location = new System.Drawing.Point(76, 27);
            this.txtPosition1.Multiline = true;
            this.txtPosition1.Name = "txtPosition1";
            this.txtPosition1.Size = new System.Drawing.Size(222, 23);
            this.txtPosition1.TabIndex = 0;
            this.txtPosition1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPositon1
            // 
            this.lblPositon1.AutoSize = true;
            this.lblPositon1.Location = new System.Drawing.Point(7, 31);
            this.lblPositon1.Name = "lblPositon1";
            this.lblPositon1.Size = new System.Drawing.Size(61, 15);
            this.lblPositon1.TabIndex = 1;
            this.lblPositon1.Text = "Position 1";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(278, 141);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(89, 28);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(183, 141);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(89, 28);
            this.btnOK.TabIndex = 6;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // frmImage3PosSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 185);
            this.Controls.Add(this.grbPositionImage);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmImage3PosSettings";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Image3Pos Settings";
            this.TopMost = true;
            this.grbPositionImage.ResumeLayout(false);
            this.grbPositionImage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbPositionImage;
        private System.Windows.Forms.Button btnPosition2;
        private System.Windows.Forms.TextBox txtPosition2;
        private System.Windows.Forms.Label lblPosition2;
        private System.Windows.Forms.Button btnPosition1;
        private System.Windows.Forms.TextBox txtPosition1;
        private System.Windows.Forms.Label lblPositon1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnPosition3;
        private System.Windows.Forms.TextBox txtPosition3;
        private System.Windows.Forms.Label lblPosition3;
    }
}