﻿namespace ATSCADA.iGraphicTools.AnimateGauge.Drawable
{
    public enum LabelPosition
    {
        Inside,
        Outside,
    }
}
