﻿namespace ATSCADA.iGraphicTools.AnimateGauge.Drawable
{
    public enum TickPosition
    {
        Inside,
        Middle,
        Outside,
    }
}
