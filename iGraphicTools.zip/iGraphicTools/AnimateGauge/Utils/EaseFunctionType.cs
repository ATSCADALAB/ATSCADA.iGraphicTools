﻿namespace ATSCADA.iGraphicTools.AnimateGauge.Utils
{
    public enum EaseFunctionType
    {
        Linear,
        Quadratic,
        Sine,
        Cubic,
    }
}
