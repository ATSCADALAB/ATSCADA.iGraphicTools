﻿namespace ATSCADA.iGraphicTools.AnimateGauge.Utils
{
    public enum EaseMode
    {
        In,
        Out,
        InOut,
    }
}
